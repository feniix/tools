/*
 * $Id: sslcat.h,v 1.1.1.1 2006/03/21 23:20:38 dave Exp $
 */
#ifndef __SSLCAT__
#define __SSLCAT__

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#define	VERSION		"1.0"

#define	BUFFER_SIZE	1024

#endif /* __SSLCAT__ */
